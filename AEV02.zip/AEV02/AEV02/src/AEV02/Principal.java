package AEV02;

public class Principal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Modelo modelo = new Modelo();
		vista vista = new vista();
		Controlador controlador = new Controlador(modelo, vista);
	}

}
