package AEV02;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Controlador {
	private Modelo modelo;
	private vista vista;
	private ActionListener actionListenerBtnBuscar;
	private ActionListener actionListenerBtnReemplazar;

	Controlador(Modelo modelo, vista vista) {
		this.modelo = modelo;
		this.vista = vista;
		control();
	}

	private void control() {

		String mensaje1 = modelo.getOriginal();
		vista.getTextAreaOriginal().setText(mensaje1);
		actionListenerBtnBuscar = new ActionListener() {
			public void actionPerformed(ActionEvent actionEvent) {
				String m = modelo.buscarPalabra(vista.getTextFieldBuscar().getText());
				vista.mostrarMensaje(m);
			}
		};
		actionListenerBtnReemplazar = new ActionListener() {
			public void actionPerformed(ActionEvent actionEvent) {
				String mod = modelo.reemplazarPalabra(vista.getTextFieldBuscar().getText(),
						vista.getTextFieldReemplazar().getText());
				vista.getTextAreaModificado().setText(mod);
			}
		};

		vista.getBtnBuscar().addActionListener(actionListenerBtnBuscar);
		vista.getBtnReemplazar().addActionListener(actionListenerBtnReemplazar);
	}
}
