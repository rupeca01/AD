package AEV02;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class Modelo {

	private String txtOriginal = "";
	private String path = "AE02_T1_2_Streams_Groucho.txt";
	private String retornoBusqueda;

	Modelo() {
		this.txtOriginal = cargaTexto(path);
	}

	public String cargaTexto(String path) {
		String txt = "";
		try {
			File myObj = new File(path);
			Scanner myReader = new Scanner(myObj);
			while (myReader.hasNextLine()) {
				String data = myReader.nextLine() + "\n";
				txt += data;
			}
			myReader.close();
		} catch (FileNotFoundException e) {
			System.out.println("An error occurred.");
			e.printStackTrace();
		}
		return txt;
	}

	public String getOriginal() {
		return txtOriginal;
	}

	public String buscarPalabra(String palabra) {

		int n = 0;
		try {
			File myObj = new File(path);
			Scanner myReader = new Scanner(myObj);
			while (myReader.hasNextLine()) {
				String strOrig = myReader.nextLine();
				int intIndex = strOrig.indexOf(palabra);
				if (intIndex == -1) {

				} else {
					n++;
				}
			}
			myReader.close();
		} catch (FileNotFoundException e) {
			System.out.println("An error occurred.");
			e.printStackTrace();
		}
		if (n == 0) {
			retornoBusqueda = "La paraula no ha sigut trobada";
		} else {
			retornoBusqueda = "La paraula ha sigut trobada " + n + " vegades";
		}
		return retornoBusqueda;

	}

	public String reemplazarPalabra(String palabra, String remp) {
		String pa = "AE02_T1_2_Streams_Groucho_Modified.txt";
		File fileNew = new File(pa);
		try {
			fileNew.createNewFile();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		String oldContent = cargaTexto(path);
		String newContent = oldContent.replaceAll(palabra, remp);
		FileWriter writer = null;
		try {
			writer = new FileWriter(pa);
			writer.write(newContent);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			try {
				writer.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return cargaTexto(pa);

	}

}
